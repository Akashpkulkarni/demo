 const Displayscore = document.getElementById('score')
 const boxes = document.getElementById('box')
 let score = 0;

 function movbox(){


      const x = Math.random()*450;
      const y = Math.random()*450;

       boxes.style.left = `${x}px`;
       boxes.style.top = `${y}px`;

 }

 boxes.addEventListener('click',()=>{


        score++;

         Displayscore.textContent = score;

         movbox();

 })
    movbox();